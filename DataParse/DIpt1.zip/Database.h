#pragma once
#include <iostream>
#include <cstdlib>
#include <fstream>
#include <sstream>
#include <vector>
#include <string>
#include "Relation.h"
#include "predicate.h"
#include "datalogProgram.h"

using namespace std;

class Database {
public:
	Database();
	virtual ~Database();

	vector<Relation> relations, toPrint;

	vector<predicate*> schemes;
	vector<predicate*> facts;
	vector<predicate*> queries;


	void addRelation(Relation);

	void fill(datalogProgram&);

	void evalQueries(vector<predicate*>&);

	string printResults();
	string printParams(vector<int>&, vector<string>&, bool, int, stringstream&);

};